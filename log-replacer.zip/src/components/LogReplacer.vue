<template>
  <div>
      <el-row type="flex" justify="center" >
          <el-col :span="6">
              <h1>Log</h1>
              <el-input type="textarea"
                        v-model="logString"
                        :rows="50"
                        placeholder="paste sql log here!"
                        ></el-input>
          </el-col>
          <el-col :span="6">
              <el-row>
                  <el-col>
                      区切り文字: <el-input placeholder="Please input" size="small" style="width:200px" v-model="pattern"></el-input>
                  </el-col>
                  <el-col>
                      <p></p>
                      <el-button type="primary" v-on:click="doParse">コンバート</el-button>
                  </el-col>
              </el-row>
          </el-col>
          <el-col :span="6">
              <h1>Query</h1>
              <el-tooltip class="item" effect="dark" content="クリックするとクリップボードにコピーします。" placement="left">
                  <pre v-on:click="doCopy" style=" text-align: left;">{{ formattedQuery }}</pre>
              </el-tooltip>

          </el-col>
      </el-row>



  </div>
</template>

<script>
import sqlFormatter from "sql-formatter";
import { Message } from 'element-ui';

export default {
  name: 'LogReplacer',
    data () {
      return {
          logString: '',
          queryString: '',
          formattedQuery: '',
          pattern: '',
          patterns: {
              patternA: '--*SetParameter ',
              patternB: '>@'
          }
      }
    },
    mounted () {
        this.queryString = localStorage.getItem("queryString")
        this.logString = localStorage.getItem("logString")
        this.formattedQuery = localStorage.getItem("formattedQuery")
        this.pattern = localStorage.getItem("pattern")
    },
    methods: {
      doCopy: function() {
          this.$copyText(this.formattedQuery).then(function (e) {
              Message({message: 'コピー完了！', type: 'success'});
              console.log(e)
          }, function (e) {
              Message({message: 'コピーに失敗しました。', type:'warning'});
              console.log(e)
          })
      },
      doParse: function () {
          let queryArea = this.logString.substring(this.logString.toLowerCase().indexOf("select "));
          const paramsArea = this.logString.substring(0, this.logString.toLowerCase().indexOf("select "));

          // get split key
          const isPatternA = paramsArea.indexOf(this.patterns.patternA) > -1
          const isPatternB = paramsArea.indexOf(this.patterns.patternB) > -1

          if (isPatternA) {
              this.pattern = this.patterns.patternA
          }

          if (isPatternB) {
              this.pattern = this.patterns.patternB
          }
          // const params = paramsArea.split(this.pattern)
          const params = paramsArea.split("\n")
          const paramList = []

          // make parameter list
          for (const param of params) {
                let paramObject = []
                if(this.pattern === this.patterns.patternA && param.indexOf(' null') === -1) {
                    paramObject = param.replace('\n', '').split(" \'")
                    paramObject[0] = paramObject[0].substring(paramObject[0].indexOf(this.patterns.patternA) + this.patterns.patternA.length, paramObject[0].length)
                    console.log(paramObject)
                }

                if(this.pattern === this.patterns.patternB && param.indexOf(this.patterns.patternB) > -1) {
                    paramObject = param.split(" := ")
                    paramObject[0] = paramObject[0].substring(paramObject[0].indexOf(this.patterns.patternB)+this.patterns.patternB.length, paramObject[0].indexOf('('))
                }
                paramList.push(paramObject)
          }

          for (const paramObject of paramList) {
              if (paramObject.length > 1) {
                  if(this.pattern === this.patterns.patternA) {
                      console.log(paramObject)
                      const keyName = '@'.concat(paramObject[0])
                      const value = "'".concat(paramObject[1])
                      queryArea = queryArea.replace(new RegExp(keyName, "gi"), value)
                  }

                  if(this.pattern === this.patterns.patternB) {
                      console.log(paramObject)
                      const keyName = '@'.concat(paramObject[0])
                      const value = paramObject[1]
                      queryArea = queryArea.replace(new RegExp(keyName, "gi"), value)
                  }

              }
          }
          this.queryString = queryArea
          this.formattedQuery = sqlFormatter.format(this.queryString)
          localStorage.setItem("queryString", this.queryString)
          localStorage.setItem("logString", this.logString)
          localStorage.setItem("formattedQuery", this.formattedQuery)
          localStorage.setItem("pattern", this.pattern)

      }
  }
}

</script>


<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
