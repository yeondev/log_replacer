import Vue from 'vue'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import App from './App.vue'
import sqlFormatter from "sql-formatter";
import VueClipboard from 'vue-clipboard2'
import Message from 'element-ui';

Vue.config.productionTip = false
Vue.use(ElementUI);
Vue.use(sqlFormatter);
Vue.use(VueClipboard);
Vue.use(Message);

new Vue({
  render: h => h(App)
}).$mount('#app')
