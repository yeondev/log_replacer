<template>
  <div>
      <el-row type="flex" justify="center" >
          <el-col :span="6">
              <h1>Log</h1>
              <el-input type="textarea"
                        v-model="logString"
                        :rows="30"
                        placeholder="paste sql log here!"
                        ></el-input>
          </el-col>
          <el-col :span="6">
              <el-row>
                  <el-col>
                      <p></p>
                      <el-button type="primary" v-on:click="doParse">コンバート</el-button>
                  </el-col>
              </el-row>
              <el-row style="text-align: left; padding-left: 15px">
                  <el-col>
                      <!--<div style="text-align: left; padding-left: 25px">-->
                          <el-tooltip class="item" effect="dark" placement="right" v-for="reportContext in reportContexts" v-bind:key="reportContext.keyName" >
                              <div slot="content">{{reportContext.foundCount}} ヵ所変更されました。</div>
                              <el-badge :value="reportContext.foundCount" class="item">
                                  <el-button size="small" v-on:click="reportContext.isToggle = !reportContext.isToggle">{{ reportContext.keyName}}</el-button>
                              </el-badge>
                          </el-tooltip>
                      <!--</div>-->
                  </el-col>
              </el-row>
          </el-col>
          <el-col :span="6">
              <h1>Query</h1>
              <el-tooltip class="item" effect="dark" content="クリックするとクリップボードにコピーします。" placement="left-start">
                  <pre v-on:click="doCopy" style="height:300px; text-align: left;">{{ formattedQuery }}</pre>
              </el-tooltip>

          </el-col>
      </el-row>
  </div>
</template>

<script>
import sqlFormatter from "sql-formatter";
import { Message } from 'element-ui';

/* eslint-disable */
export default {
  name: 'LogReplacer',
    data () {
      return {
          logString: '',
          queryString: '',
          formattedQuery: '',
          reportContexts: [],
          pattern: '',
          patterns: {
              patternA: '--*SetParameter ',
              patternB: '>@'
          }
      }
    },
    mounted () {
        this.queryString = localStorage.getItem("queryString")
        this.logString = localStorage.getItem("logString")
        this.formattedQuery = localStorage.getItem("formattedQuery")
        this.pattern = localStorage.getItem("pattern")
    },
    methods: {
      doCopy: function() {
          this.$copyText(this.formattedQuery).then(function (e) {
              Message({message: 'コピー完了！', type: 'success'});
              console.log(e)
          }, function (e) {
              Message({message: 'コピーに失敗しました。', type:'warning'});
              console.log(e)
          })
      },
      doParse: function () {
          this.reportContexts = []
          let queryArea = this.logString.substring(this.logString.toLowerCase().indexOf("select "));
          const paramsArea = this.logString.substring(0, this.logString.toLowerCase().indexOf("select "));

          // get split key
          const isPatternA = paramsArea.indexOf(this.patterns.patternA) > -1
          const isPatternB = paramsArea.indexOf(this.patterns.patternB) > -1

          if (isPatternA) {
              this.pattern = this.patterns.patternA
          }

          if (isPatternB) {
              this.pattern = this.patterns.patternB
          }
          const params = paramsArea.split("\n")
          const paramList = []

          // make parameter list
          for (const param of params) {
                let paramObject = []
                if(this.pattern === this.patterns.patternA && param.indexOf(' null') === -1) {
                    paramObject = param.replace('\n', '').split(" \'")
                    paramObject[0] = paramObject[0].substring(paramObject[0].indexOf(this.pattern) + this.pattern.length, paramObject[0].length)
                }

                if(this.pattern === this.patterns.patternB && param.indexOf(this.patterns.patternB) > -1) {
                    paramObject = param.split(" := ")
                    paramObject[0] = paramObject[0].substring(paramObject[0].indexOf(this.pattern) + this.pattern.length, paramObject[0].indexOf('('))
                }

                if (paramObject && paramObject.length > 0) {
                    paramList.push(paramObject)
                }
          }

          // 중복 키가 있는지 확인
          const includedTextObjects = this.getDuplicatedKeyObjects(paramList, [])

          // 예외처리 리스트를 제일 나중에 변환하도록 재정렬처리
          const sortedParamList = []
          let sortIndex = 0
          for (const paramObject of paramList) {
              sortIndex++
              paramObject[2] = sortIndex
              if (includedTextObjects.filter(data => data[0] === paramObject[0]).length === 0){
                  // 예외처리 리스트를 제외하고 리스트를 재생성
                  sortedParamList.push(paramObject)
              }
          }

          // 예외처리 리스트를 가장 나중에 추가
          for (const paramObject of includedTextObjects.reverse()) {
              sortedParamList.push(paramObject)
          }

          // convert
          for (const paramObject of sortedParamList) {
              if (paramObject.length > 1 && paramObject[0].trim() !== '' && paramObject[1]) {
                  let keyName = '@'.concat(paramObject[0])
                  let value
                  if (this.pattern === this.patterns.patternA) {
                      value = "'".concat(paramObject[1])
                  }

                  if (this.pattern === this.patterns.patternB) {
                      value = paramObject[1]
                  }

                  this.reportContexts.push({
                      keyName: keyName,
                      value: value,
                      isToggle: false,
                      sortIndex: paramObject[2],
                      foundCount: 0
                  })
                  this.countContainText(queryArea, keyName)

                  queryArea = queryArea.replace(new RegExp(keyName, "gi"), value)
              }
          }
          this.queryString = queryArea
          this.formattedQuery = sqlFormatter.format(this.queryString)
          this.reportContexts.sort((a, b) => a.sortIndex < b.sortIndex ? -1 : a.sortIndex > b.sortIndex ? 1 : 0)

          localStorage.setItem("queryString", this.queryString)
          localStorage.setItem("logString", this.logString)
          localStorage.setItem("formattedQuery", this.formattedQuery)
          localStorage.setItem("pattern", this.pattern)
      },
      countContainText: function(queryArea, keyName) {
          const idx = queryArea.indexOf(keyName)
          if (idx > -1) {
              this.reportContexts.filter(data => {
                  if (data.keyName === keyName) {
                      data.foundCount++
                  }
              })
              this.countContainText(queryArea.substring(idx+keyName.length), keyName)
          }
      },
      getDuplicatedKeyObjects: function (list, returnList) {
          for (const paramObjectSource of list) {
              if (paramObjectSource[0].trim() === '') continue

              // 특정 키가 다른 키 문자열에 2건 이상 포함되어있는 케이스를 확인 (code1 / code11, code12 .. 처럼)
              let count = 0
              for (const paramObjectTarget of list) {
                  if (paramObjectTarget[0].trim() === '') continue

                  if (paramObjectTarget[0].indexOf(paramObjectSource[0]) > -1) {
                      count++

                      if (count > 1) {
                          // 특정 키가 다른 키 문자열에 포함되어 있을 경우 예외처리리스트에 추가 하고 다음 로직으로 진행
                          returnList.push(paramObjectSource)

                          break
                      }
                  }
              }
          }
          return returnList
      }
  }
}

</script>


<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}

.item {
    margin-top: 10px;
    margin-right: 40px;
}
</style>
